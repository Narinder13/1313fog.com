// Collections Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initCollectionTabs();
    initCollectionAnimations();
});

// Collection Tabs Functionality
function initCollectionTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const collectionSections = document.querySelectorAll('.collection-section');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');
            
            // Remove active class from all tabs and sections
            tabButtons.forEach(btn => btn.classList.remove('active'));
            collectionSections.forEach(section => section.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Show corresponding section
            const targetSection = document.getElementById(targetTab);
            if (targetSection) {
                targetSection.classList.add('active');
                
                // Trigger AOS refresh for the new section
                if (typeof AOS !== 'undefined') {
                    AOS.refresh();
                }
                
                // Smooth scroll to collection navigation (header goes behind navbar)
                setTimeout(() => {
                    const collectionNav = document.querySelector('.collection-nav');
                    if (collectionNav) {
                        const navbarHeight = document.querySelector('.navbar').offsetHeight;
                        const targetPosition = collectionNav.offsetTop - navbarHeight;
                        
                        window.scrollTo({
                            top: targetPosition,
                            behavior: 'smooth'
                        });
                    }
                }, 100);
            }
        });
    });
}

// Collection-specific animations
function initCollectionAnimations() {
    // Product card hover effects
    const productCards = document.querySelectorAll('.product-card');
    
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
            this.style.boxShadow = '0 20px 40px rgba(0,0,0,0.1)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
        });
    });
    
    // Collection image parallax effect
    window.addEventListener('scroll', function() {
        const collectionImages = document.querySelectorAll('.collection-image img');
        const scrolled = window.pageYOffset;
        
        collectionImages.forEach(img => {
            const rect = img.getBoundingClientRect();
            const speed = 0.1;
            
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                const yPos = -(scrolled * speed);
                img.style.transform = `translateY(${yPos}px)`;
            }
        });
    });
}
