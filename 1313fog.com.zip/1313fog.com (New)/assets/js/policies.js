// Policies Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        offset: 100
    });

    // Policy Tab Navigation
    const policyTabs = document.querySelectorAll('.policy-tab');
    const policySections = document.querySelectorAll('.policy-section');

    function showPolicy(policyId) {
        // Hide all policy sections
        policySections.forEach(section => {
            section.classList.remove('active');
        });

        // Remove active class from all tabs
        policyTabs.forEach(tab => {
            tab.classList.remove('active');
        });

        // Show selected policy section
        const selectedSection = document.getElementById(`${policyId}-policy`);
        if (selectedSection) {
            selectedSection.classList.add('active');
        }

        // Add active class to clicked tab
        const selectedTab = document.querySelector(`[data-policy="${policyId}"]`);
        if (selectedTab) {
            selectedTab.classList.add('active');
        }

        // Smooth scroll to policy section
        if (selectedSection) {
            selectedSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    // Add click event listeners to policy tabs
    policyTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const policyId = this.getAttribute('data-policy');
            showPolicy(policyId);
        });
    });

    // URL hash handling for direct links
    function handleHashChange() {
        const hash = window.location.hash;
        if (hash) {
            const policyId = hash.replace('#', '').replace('-policy', '');
            if (['return', 'refund', 'privacy', 'terms'].includes(policyId)) {
                showPolicy(policyId);
            }
        }
    }

    // Handle initial hash
    handleHashChange();

    // Handle hash changes
    window.addEventListener('hashchange', handleHashChange);

    // Smooth scrolling for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Animate policy items on scroll
    const observeOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observeOptions);

    // Observe policy items
    const policyItems = document.querySelectorAll('.policy-item, .refund-card, .info-item, .right-item');
    policyItems.forEach(item => {
        item.style.opacity = '0';
        item.style.transform = 'translateY(20px)';
        item.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(item);
    });

    // Stagger animation for process steps
    const processSteps = document.querySelectorAll('.step');
    processSteps.forEach((step, index) => {
        step.style.opacity = '0';
        step.style.transform = 'translateX(-20px)';
        step.style.transition = `opacity 0.6s ease ${index * 0.2}s, transform 0.6s ease ${index * 0.2}s`;
        observer.observe(step);
    });

    // Highlight important terms
    const importantTerms = [
        '15 days',
        '15-day',
        'original condition',
        'receipt required',
        'store credit',
        'non-returnable'
    ];

    function highlightTerms() {
        const textElements = document.querySelectorAll('p, li');
        textElements.forEach(element => {
            let content = element.innerHTML;
            importantTerms.forEach(term => {
                const regex = new RegExp(`\\b(${term})\\b`, 'gi');
                content = content.replace(regex, '<span class="highlight-term">$1</span>');
            });
            element.innerHTML = content;
        });
    }

    // Apply highlighting after a short delay
    setTimeout(highlightTerms, 1000);

    // Add click tracking for policy sections
    const trackPolicyView = (policyName) => {
        // This would integrate with analytics
        console.log(`Policy viewed: ${policyName}`);
    };

    policyTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const policyName = this.querySelector('i').nextSibling.textContent.trim();
            trackPolicyView(policyName);
        });
    });

    // FAQ Toggle Functionality (if needed in future)
    function initializeFAQ() {
        const faqItems = document.querySelectorAll('.faq-item');
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            const answer = item.querySelector('.faq-answer');
            
            if (question && answer) {
                question.addEventListener('click', function() {
                    const isOpen = item.classList.contains('open');
                    
                    // Close all FAQ items
                    faqItems.forEach(faq => {
                        faq.classList.remove('open');
                        const faqAnswer = faq.querySelector('.faq-answer');
                        if (faqAnswer) {
                            faqAnswer.style.maxHeight = '0';
                        }
                    });
                    
                    // Open clicked item if it wasn't already open
                    if (!isOpen) {
                        item.classList.add('open');
                        answer.style.maxHeight = answer.scrollHeight + 'px';
                    }
                });
            }
        });
    }

    // Print functionality
    function addPrintButton() {
        const printButton = document.createElement('button');
        printButton.className = 'btn btn-outline print-btn';
        printButton.innerHTML = '<i class="fas fa-print"></i> Print Policy';
        printButton.style.position = 'fixed';
        printButton.style.bottom = '100px';
        printButton.style.right = '20px';
        printButton.style.zIndex = '1000';
        
        printButton.addEventListener('click', function() {
            window.print();
        });
        
        document.body.appendChild(printButton);
    }

    // Add print button
    addPrintButton();

    // Keyboard navigation for policy tabs
    policyTabs.forEach((tab, index) => {
        tab.setAttribute('tabindex', '0');
        tab.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            } else if (e.key === 'ArrowRight') {
                e.preventDefault();
                const nextIndex = (index + 1) % policyTabs.length;
                policyTabs[nextIndex].focus();
            } else if (e.key === 'ArrowLeft') {
                e.preventDefault();
                const prevIndex = (index - 1 + policyTabs.length) % policyTabs.length;
                policyTabs[prevIndex].focus();
            }
        });
    });

    // Search functionality within policies
    function addSearchFunctionality() {
        const searchContainer = document.createElement('div');
        searchContainer.className = 'policy-search';
        searchContainer.innerHTML = `
            <div class="search-box">
                <input type="text" placeholder="Search policies..." id="policySearch">
                <i class="fas fa-search"></i>
            </div>
        `;
        
        const policyNav = document.querySelector('.policy-nav');
        if (policyNav) {
            policyNav.appendChild(searchContainer);
        }
        
        const searchInput = document.getElementById('policySearch');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const allText = document.querySelectorAll('.policy-content p, .policy-content li, .policy-content h3, .policy-content h4');
                
                // Remove previous highlights
                allText.forEach(element => {
                    element.innerHTML = element.textContent;
                });
                
                if (searchTerm.length > 2) {
                    allText.forEach(element => {
                        const text = element.textContent;
                        if (text.toLowerCase().includes(searchTerm)) {
                            const regex = new RegExp(`(${searchTerm})`, 'gi');
                            element.innerHTML = text.replace(regex, '<mark>$1</mark>');
                        }
                    });
                }
            });
        }
    }

    // Add search functionality
    setTimeout(addSearchFunctionality, 500);

    // Mobile optimization
    function optimizeForMobile() {
        if (window.innerWidth <= 768) {
            // Stack policy tabs vertically on mobile
            const policyNav = document.querySelector('.policy-nav');
            if (policyNav) {
                policyNav.style.flexDirection = 'column';
                policyNav.style.gap = '0.5rem';
            }
            
            // Adjust tab click behavior for mobile
            policyTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    // Add a small delay for mobile tap
                    setTimeout(() => {
                        const activeSection = document.querySelector('.policy-section.active');
                        if (activeSection) {
                            activeSection.scrollIntoView({
                                behavior: 'smooth',
                                block: 'start'
                            });
                        }
                    }, 100);
                });
            });
        }
    }

    // Run mobile optimization
    optimizeForMobile();
    
    // Re-run on window resize
    window.addEventListener('resize', optimizeForMobile);

    console.log('FOG Fashion Policies page initialized successfully!');
});
