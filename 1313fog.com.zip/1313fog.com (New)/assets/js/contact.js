// Contact Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initStoreTabs();
    initContactForm();
    initLocationFeatures();
});

// Store Tabs Functionality
function initStoreTabs() {
    const storeTabs = document.querySelectorAll('.store-tab');
    const storeDetails = document.querySelectorAll('.store-detail');
    
    storeTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetStore = this.getAttribute('data-store');
            
            // Remove active class from all tabs and details
            storeTabs.forEach(t => t.classList.remove('active'));
            storeDetails.forEach(detail => detail.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Show corresponding store detail
            const targetDetail = document.getElementById(targetStore);
            if (targetDetail) {
                targetDetail.classList.add('active');
                
                // Trigger AOS refresh
                if (typeof AOS !== 'undefined') {
                    AOS.refresh();
                }
            }
        });
    });
}

// Contact Form Functionality
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(contactForm);
            const data = Object.fromEntries(formData);
            
            // Validate form
            if (validateContactForm(data)) {
                // Show loading state
                const submitBtn = contactForm.querySelector('.form-submit');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
                submitBtn.disabled = true;
                
                // Simulate form submission
                setTimeout(() => {
                    // Show success message
                    showNotification('Thank you! Your message has been sent successfully. We\'ll get back to you soon.', 'success');
                    
                    // Reset form
                    contactForm.reset();
                    
                    // Reset button
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                    
                    // In a real implementation, you would send the data to your server here
                    console.log('Form data:', data);
                }, 2000);
            } else {
                showNotification('Please fill in all required fields correctly.', 'error');
            }
        });
    }
}

// Form validation
function validateContactForm(data) {
    // Check required fields
    if (!data.name || !data.email || !data.message) {
        return false;
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
        return false;
    }
    
    // Validate name (at least 2 characters)
    if (data.name.trim().length < 2) {
        return false;
    }
    
    // Validate message (at least 10 characters)
    if (data.message.trim().length < 10) {
        return false;
    }
    
    return true;
}

// Location-based features
function initLocationFeatures() {
    // Add click handlers for social media buttons
    const socialBtns = document.querySelectorAll('.social-btn');
    socialBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });
    
    // Add hover effects for contact cards
    const contactCards = document.querySelectorAll('.contact-card');
    contactCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 10px 30px rgba(0,0,0,0.1)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
        });
    });
}

// Find nearest store functionality
function findNearestStore() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            const userLat = position.coords.latitude;
            const userLon = position.coords.longitude;
            
            // Store locations (approximate coordinates)
            const stores = [
                { name: 'Bathinda', lat: 30.2107, lon: 74.9455, url: 'https://bit.ly/2XT9Uaw' },
                { name: 'Barnala', lat: 30.3787, lon: 75.5461, url: 'https://bit.ly/2XXSEBi' },
                { name: 'Zira', lat: 30.9636, lon: 74.9900, url: 'https://l1nq.com/IH3YK' },
                { name: 'Kotkapura', lat: 30.5820, lon: 74.8330, url: 'https://bit.ly/3rGrYCb' },
                { name: 'Mansa', lat: 29.9988, lon: 75.3933, url: 'https://shorturl.at/hOWmD' }
            ];
            
            // Calculate distances and find nearest
            let nearestStore = null;
            let minDistance = Infinity;
            
            stores.forEach(store => {
                const distance = calculateDistance(userLat, userLon, store.lat, store.lon);
                if (distance < minDistance) {
                    minDistance = distance;
                    nearestStore = store;
                }
            });
            
            if (nearestStore) {
                const message = `Your nearest FOG store is in ${nearestStore.name}. Would you like to get directions?`;
                if (confirm(message)) {
                    window.open(nearestStore.url, '_blank');
                }
            }
        }, function(error) {
            // Fallback to showing all locations
            showNotification('Unable to detect your location. Please check our store locations below.', 'info');
            document.querySelector('.locations-section').scrollIntoView({ behavior: 'smooth' });
        });
    } else {
        showNotification('Geolocation is not supported by this browser.', 'error');
    }
}

// Calculate distance between two coordinates
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c; // Distance in kilometers
    return distance;
}

// Form input enhancements
document.addEventListener('DOMContentLoaded', function() {
    const formInputs = document.querySelectorAll('input, textarea');
    
    formInputs.forEach(input => {
        // Add focus effects
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
            
            // Add filled class if input has value
            if (this.value.trim() !== '') {
                this.parentElement.classList.add('filled');
            } else {
                this.parentElement.classList.remove('filled');
            }
        });
        
        // Real-time validation
        input.addEventListener('input', function() {
            validateField(this);
        });
    });
});

// Individual field validation
function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.name;
    const formGroup = field.parentElement;
    
    // Remove previous validation classes
    formGroup.classList.remove('error', 'success');
    
    if (field.hasAttribute('required') && value === '') {
        formGroup.classList.add('error');
        return false;
    }
    
    switch (fieldName) {
        case 'email':
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (value && !emailRegex.test(value)) {
                formGroup.classList.add('error');
                return false;
            }
            break;
        case 'phone':
            const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
            if (value && !phoneRegex.test(value.replace(/\s/g, ''))) {
                formGroup.classList.add('error');
                return false;
            }
            break;
        case 'name':
            if (value && value.length < 2) {
                formGroup.classList.add('error');
                return false;
            }
            break;
        case 'message':
            if (value && value.length < 10) {
                formGroup.classList.add('error');
                return false;
            }
            break;
    }
    
    if (value) {
        formGroup.classList.add('success');
    }
    
    return true;
}
